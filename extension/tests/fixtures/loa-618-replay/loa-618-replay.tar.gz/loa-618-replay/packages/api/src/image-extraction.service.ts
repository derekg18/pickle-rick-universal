export class ImageExtractionService {
  transformToByteArray(input: string): Uint8Array {
    return new TextEncoder().encode(input);
  }
}
