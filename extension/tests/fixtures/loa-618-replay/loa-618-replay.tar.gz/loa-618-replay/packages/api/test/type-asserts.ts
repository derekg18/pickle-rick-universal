// @typescript-eslint/no-unnecessary-type-assertion × 2 fixture
const x: string = 'hello';
const y = x as string;  // unnecessary assertion
const z = x as string;  // unnecessary assertion
export { y, z };
