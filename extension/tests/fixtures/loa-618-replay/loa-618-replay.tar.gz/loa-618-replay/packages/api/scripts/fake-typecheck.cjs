'use strict';
process.stderr.write(
  'src/test/image-extraction.service.spec.ts(95,11): error TS2352: ' +
  "Conversion of type 'typeof MockImageExtractionService' to type " +
  "'ImageExtractionService' may be a mistake because neither type " +
  'sufficiently overlaps with the other.\n' +
  'Found 1 error.\n'
);
process.exit(1);
