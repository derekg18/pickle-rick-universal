// TS2352 fixture: mock missing transformToByteArray
import type { ImageExtractionService } from '../src/image-extraction.service';

class MockImageExtractionService {
  // transformToByteArray intentionally omitted
}

const service = new MockImageExtractionService() as unknown as ImageExtractionService;
export { service };
