// no-control-regex × 2 fixture
export function validateInput(s: string): boolean {
  // \x01 in character class range — no-control-regex
  return /[\x01-\x1f]/.test(s) || /[\x80-\x9f]/.test(s);
}
