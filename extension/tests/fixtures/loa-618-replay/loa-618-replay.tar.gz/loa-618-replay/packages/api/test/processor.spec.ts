// require-await × 3 fixture
export async function getFoo(): Promise<string> {
  return 'foo';
}
export async function getBar(): Promise<string> {
  return 'bar';
}
export async function getBaz(): Promise<string> {
  return 'baz';
}
