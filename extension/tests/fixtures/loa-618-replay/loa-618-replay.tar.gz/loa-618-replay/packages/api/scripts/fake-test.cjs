'use strict';
process.stdout.write('All tests passed (synthesized fixture).\n');
process.exit(0);
